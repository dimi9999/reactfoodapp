self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "95416cbb7028087135bbd74b0e894f69",
    "url": "./index.html"
  },
  {
    "revision": "15218345faa98cf2f664",
    "url": "./static/css/main.ff199b7e.chunk.css"
  },
  {
    "revision": "a4b7f337b9f6b213b65c",
    "url": "./static/js/2.92a2f8f0.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.92a2f8f0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15218345faa98cf2f664",
    "url": "./static/js/main.edc74a25.chunk.js"
  },
  {
    "revision": "f0ca750427f11c8e2357",
    "url": "./static/js/runtime-main.3e1f3381.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);