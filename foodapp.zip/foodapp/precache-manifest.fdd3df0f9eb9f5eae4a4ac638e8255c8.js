self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a1df5c99bb9f75f135ca26451b6daade",
    "url": "/foodapp/index.html"
  },
  {
    "revision": "3605599c4768750f7542",
    "url": "/foodapp/static/css/main.ff199b7e.chunk.css"
  },
  {
    "revision": "37373d3ee3a291f3b5aa",
    "url": "/foodapp/static/js/2.6234d04e.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/foodapp/static/js/2.6234d04e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3605599c4768750f7542",
    "url": "/foodapp/static/js/main.d4ace6cf.chunk.js"
  },
  {
    "revision": "f0bf9c9668634a2861e0",
    "url": "/foodapp/static/js/runtime-main.f97895e9.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/foodapp/static/media/logo.5d5d9eef.svg"
  }
]);