self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f0282dc7fac511d1ad826c6e3d21e369",
    "url": "/foodapp/index.html"
  },
  {
    "revision": "79c1069813c1b3341b49",
    "url": "/foodapp/static/css/main.ff199b7e.chunk.css"
  },
  {
    "revision": "37373d3ee3a291f3b5aa",
    "url": "/foodapp/static/js/2.6234d04e.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/foodapp/static/js/2.6234d04e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "79c1069813c1b3341b49",
    "url": "/foodapp/static/js/main.3ac4daf7.chunk.js"
  },
  {
    "revision": "f0bf9c9668634a2861e0",
    "url": "/foodapp/static/js/runtime-main.f97895e9.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/foodapp/static/media/logo.5d5d9eef.svg"
  }
]);